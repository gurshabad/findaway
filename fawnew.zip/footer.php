<div id="footer">
	<div class="container">
		<div class="row">
			<div class="col-md-1">
			</div>
			<div class="col-md-10">
				<center>
				<div class="row">
				<div class="col-md-1 footeritem"><a class="footeritem" href="./index.php">HOME</a></div>
				<div class="text-muted col-md-1">&middot;</div>
				<div class="col-md-1 footeritem"><a class="footeritem" href="./whatwedo.php">ABOUT</a></div>
				<div class="text-muted col-md-1">&middot;</div>
				<div class="col-md-1 footeritem"><a class="footeritem" href="./projects.php">PROJECTS</a></div>
				<div class="text-muted col-md-1">&middot;</div>
				<div class="col-md-1 footeritem"><a class="footeritem" href="http://helpingyoufindaway.tumblr.com">BLOG</a></div>
				<div class="text-muted col-md-1">&middot;</div>
				<div class="col-md-1 footeritem"><a class="footeritem" href="./join-in.php">JOIN IN</a></div>
				<div class="text-muted col-md-1">&middot;</div>
				<div class="col-md-1 footeritem"><a class="footeritem" href="./contact.php">CONTACT</a></div>
				</div>
				</center>
			</div>
			<div class="col-md-1">
			</div>
		</div>
		<div class="row" style="padding-top: 20px">
			<div class="text-muted col-md-12" style="text-align: center">
				Find A Way &copy; 2014
			</div>
		</div>
	</div>
</div>