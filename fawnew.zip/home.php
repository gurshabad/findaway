<!DOCTYPE html>
<html lang="en">
	<head>
	<title>Find A Way | Home</title>
	<meta charset="utf-8">
	<link rel="icon" href="./img/favicon.ico" type="image/x-icon">
	<link rel="shortcut icon" href="./img/favicon.ico" type="image/x-icon" />
	<link rel="stylesheet" href="./css/bootstrap.css">
	<link rel="stylesheet" href="./css/raleway.css">
	<link rel="stylesheet" href="./css/superfish.css">
	<link rel="stylesheet" href="./css/superfish-navbar.css">
	<link rel="stylesheet" href="./css/subscribe-form.css">
	<link rel="stylesheet" href="./css/new.css">
	<script src="./js/jquery.js"></script>
	<script src="./js/superfish.js"></script>
	<script src="./js/bootstrap.js"></script>
	<script src="./js/imgLiquid.js"></script>
	<script src="./js/sForm.js"></script>
	</head>

<body>
	<?php include('navbar.php') ?>
<!-- NAVBAR ENDS -->
<div class="fadein">
	<img src="./img/slides/slide3.jpg">
	<img src="./img/slides/slide1.jpg">
	<img src="./img/slides/slide2.jpg">
</div>
<div style="margin-top:350px;"></div>
<!-- PICTURE DIV ENDS -->
<div class="container">
<div class="row">
	<div class="page-title col-md-3">
		<h2>FIND A WAY - AN INTRODUCTION</h2>
	</div>
	<div class="page-content col-md-9">
		<p></p>
		<p>Find A Way is about helping you help others. We are on a mission to change the world. On. Our. Own.Terms.</p>
		<p>Working in close collaboration with the NGOs, we bridge the gap between their efforts and your desire to help. Know more about what we're trying to do through our introductory video.</p>
		<p> <object><param name="movie" value="http://www.youtube.com/v/3NtaOs-sxi0?hl=en_US&;version=3&autoplay=1&rel=0&autohide=1&showinfo=0"></param><param name="allowFullScreen" value="true"></param><param name="allowscriptaccess" value="always"></param><embed src="http://www.youtube.com/v/3NtaOs-sxi0?hl=en_US&;version=3&autoplay=1&rel=0&autohide=1&showinfo=0" type="application/x-shockwave-flash" width="100%" height="500" allowscriptaccess="always" allowfullscreen="true"></embed></object></p>
	</div>
</div>
<div class="row">
	<div class="page-title col-md-3">
		<h2>WHAT'S NEW</h2>
	</div>
	<div class="page-content col-md-9">
		<p></p>
		<p><h3 class="text-muted">February 10, 2014</h3></p>
		<p>IIIT-D is covering its home-grown NGO! Have a look at the <a href="http://iiitd.ac.in/news/find-a-way">article on the IIIT-D website</a>.</p>
		<p style="text-align: center;"><img src="./img/pages/home-story-1.jpg" style="width: 80%; height: auto;"></p>
		<hr>
		<p></p>
		<p><h3 class="text-muted">February 3, 2014</h3></p>
		<p>Project Incentivize - Capture A Moment is launched!</p>
		<p style="text-align: center;"><img src="./img/pages/incentivize.jpg" style="width: 80%; height: auto;"></p>
		<p>A fun way to inspire others to follow your lead in helping out others -- post an original photo of a good deed, and you could win eBay vouchers and restaurant coupons worth Rs. 1,500!</p>
		<hr>
		<p></p>
		<p><h3 class="text-muted">January 31, 2014 - February 1, 2014</h3></p>
		<div class="row">
			<div class="col-md-4">
				<img src="./img/pages/odyssey.png" style="width: 100%; height: auto;">
			</div>
			<div class="col-md-8">
				<p>The Find A Way stall at Odyssey’14, IIIT-Delhi’s first-ever cultural fest was a roaring success!</p>
				<p>People who bought the Find A Way card were invited to leave an orange footprint and a message on sheets of paper. They found a fun way to help others; what about you? :D</p>
				<p>Check out <a href="https://www.facebook.com/media/set/?set=a.1460809010808685.1073741832.1434693996753520">more photos</a> on our <a href="http://facebook.com/find.a.way">Facebook page</a>!</p>
			</div>
		</div>
		<hr>
		<p></p>
		<p><h3 class="text-muted">January 27, 2014</h3></p>
		<div class="row">
			<div class="col-md-7">
				<p>Find A Way was featured in University Express!</p>
				<p>Read the full article <a href="http://www.universityexpress.co.in/delhiuniversity/2014/01/in-conversation-with-find-a-way/">here</a> as Kavya Saxena from University Express interviews Rohan Katyal.</p>
				<p class="text-muted"><i>"This way we also cater to the people who believe in our cause and choose to contribute to the cause."</i></p>
			</div>
			<div class="col-md-5">
				<img src="./img/pages/home-story-2.jpg" style="width: 100%; height: auto;">
			</div>
		</div>
		<hr>
		<p></p>
		<p><h3 class="text-muted">January 19, 2014</h3></p>
		<p>The Find A Way Card is released! The Card gets you special discounts at over 120 restaurants across Delhi, and is an awesome way to help out a child in need.</p>
		<p>All profits from the sale of the card go towards sponsoring the education of under-privileged children, through our partner <a href="http://cwcs.in">CWCS</a>.</p>
		<p>Have a look <a href="http://findaway.in/card/">here</a> for more information on how to get your card, and which restaurants it works in.</p>
		<p style="text-align: center;"><img src="./img/pages/find-a-way-card.png" style="width: 60%; height: auto;"></p>

	</div>
</div>
</div>
<!-- PREFOOTER -->
	<?php include('prefooter.php') ?>
<!-- FOOTER -->
	<?php include('footer.php') ?>
	<!-- The Javascript begins -->
	<script>
	jQuery(document).ready(function(){
		jQuery('ul.sf-menu').superfish({
			pathClass:	'current'
		});
	});
	</script>
	<script>
	$(document).ready(function() {
    $(".imgLiquidFill").imgLiquid();
	});
	</script>
	<script>
	function myFocus(element){
			 if (element.value == element.defaultValue){
					 element.focus();
					 element.value = '';
			 }
		}
		function myBlur(element){
			 if (element.value == ''){
					 element.blur();
					 element.value = element.defaultValue;
			 }
		}
	</script>
	<script type="text/javascript">
		$(function() {
		$('.fadein img:gt(0)').hide();

		setInterval(function () {
    	$('.fadein :first-child').fadeOut()
                             .next('img')
                             .fadeIn()
                             .end()
                             .appendTo('.fadein');
		}, 4000); // 4 seconds
		});
	</script>
</body>
</html>