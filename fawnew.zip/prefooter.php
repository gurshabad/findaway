<div class="row" id="prefooter">
	<div class="page-title col-md-2">
		
	</div>
	<div class="page-content col-md-2">
		<h3 class="prefooter-title">SUPPORT</h3>
		<p>Help us raise funds and keep things going!</p><br>
		<p>
			<a class="btn btn-lg btn-primary" style="background: #ef6104; border: none;">DONATE NOW</a>
		</p>
	</div>
	<div class="page-title col-md-6">
		<h3 class="prefooter-title">STAY CONNECTED</h3>
		<div class="row">
		<div class="col-md-9">
		<p> Subscribe to our mailing list for regular updates on our projects and more!</p>
		<form id="subscribe-form">
			<div class="success">Your subscription request has been sent!</div>
				<fieldset>
					<label class="email">
						<input type="email" value="Enter Your Email" onFocus="myFocus(this);" onBlur="myBlur(this);"/>
						<span class="error">*This is not a valid email address.</span>
					</label>
					<a href="#" id="okaybtn" data-type="submit">OK</a>
				</fieldset>
		</form>
		</div>
		<div class="col-md-3">
			<a href="mailto:contact@findaway.in"><img class="socialicon" src="./img/social/email-icon.png"></a>
			<a href="http://facebook.com/find.a.way/"><img class="socialicon" src="./img/social/fb-icon.png"></a>
			<a href="http://helpingyoufindaway.tumblr.com/"><img class="socialicon" src="./img/social/tumblr-icon.png"></a>
			<a href="http://www.youtube.com/channel/UCyEg-8TrKyLx1pxHXo4UGSQ"><img class="socialicon" src="./img/social/youtube-icon.png"></a>
			<a href="https://twitter.com/findawayteam"><img class="socialicon img-circle" src="./img/social/twitter-icon.jp	g"></a>
		</div>
		</div>
	</div>
	<div class="page-content col-md-2">
		
	</div>
</div>